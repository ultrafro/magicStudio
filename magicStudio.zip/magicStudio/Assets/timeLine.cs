﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class timeLine : MonoBehaviour {


    List<GameObject> timeBlockList;
    public GameObject timeBlockPrefab;
    public GameObject sb;
    public GameObject blockModel;
    public GameObject timelineModel;
    public GameObject storage;
    

    // Use this for initialization
    void Start () {
        timeBlockList = new List<GameObject>();
	}
	
	// Update is called once per frame
	void Update () {
        manageBlocks();
	}

    float factor = 1.2f / (300.0f * 30.0f);
    void manageBlocks()
    {
        //shift around the blocks so that they are in the right place
        foreach(Transform t in gameObject.transform.parent)
        {
            if(t.gameObject.name == "timeBlock(Clone)")
            {
                //re-adjust width
                GameObject tb = t.gameObject;
                GameObject mclip = tb.GetComponent<timeBlock>().associatedMclip;
                int newSize = mclip.GetComponent<magicClip>().endClipFrame - mclip.GetComponent<magicClip>().startClipFrame;
                Vector3 newScale = t.localScale;
                newScale.x = newSize * factor;
                t.localScale = newScale;


                //align it?
                GameObject dummy = new GameObject();
                dummy.transform.position = t.position;
                dummy.transform.rotation = t.rotation;
                dummy.transform.parent = timelineModel.transform;
                Vector3 newPosition = dummy.transform.localPosition;
                newPosition.y = 0.0f;
                dummy.transform.localPosition = newPosition;
                dummy.transform.rotation = timelineModel.transform.rotation;
                t.position = dummy.transform.position;
                t.rotation = dummy.transform.rotation;
                GameObject.Destroy(dummy);



            }
        }


    }

    void OnTriggerStay(Collider other)
    {

        //if other is magic clip & magic clip is not being held by anything
        if (other.gameObject.GetComponent<magicClip>() != null)
        {

            GameObject mclip = other.gameObject;
            if(mclip.transform.parent == null)
            {

                GameObject newMclip = Instantiate(mclip);
                storage.GetComponent<storage>().addClip(mclip);


                //create a block, add it to the list



                GameObject tb = (GameObject)Instantiate(timeBlockPrefab);
                tb.GetComponent<timeBlock>().loadClip(newMclip,blockModel);
                tb.GetComponent<draggable>().previousParent = gameObject.transform.parent.gameObject;
                tb.transform.parent = gameObject.transform.parent;
                timeBlockList.Add(tb);


                //move the clip to the storyboard, important to do this after creatign timeblock for positional purposes
                //try just making a copy

                //GameObject newMclip = mclip.GetComponent<magicClip>().deepCopy();
                GameObject.Destroy(newMclip.GetComponent<draggable>());
                //newMclip.RemoveComponent<draggable>();
                //newMclip.GetComponent<draggable>().enabled = false;
                sb.GetComponent<storyBoard>().addClip(newMclip);
            }


        }








    }
}

