﻿using UnityEngine;
using System.Collections;

public class fpsDisplay : MonoBehaviour {

    public GameObject text3d;
    private float fps;

    float deltaTime = 0.0f;

    // Use this for initialization
    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        deltaTime += (Time.deltaTime - deltaTime) * 0.1f;
        float msec = deltaTime * 1000.0f;
        float fps = 1.0f / deltaTime;
        string fpsText = string.Format("{0:0.0} ms ({1:0.} fps)", msec, fps);
        text3d.GetComponent<TextMesh>().text = "FPS display: " + fpsText;
	
	}
}
