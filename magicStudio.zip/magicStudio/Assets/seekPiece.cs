﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class seekPiece : MonoBehaviour {

    public GameObject preview;
    public GameObject timeline;
    public GameObject filmPlayButton;
    List<GameObject> timeBlockList;
    Texture2D logo;

	// Use this for initialization
	void Start () {
        timeBlockList = new List<GameObject>();


        byte[] bytes = File.ReadAllBytes("C:\\Users\\hisham\\Documents\\UnityProjects\\magicStudio\\Assets\\MAGIC-LOGO-BLK-BG.png"); //load bytes from image file to cpu
        logo = new Texture2D(2, 2);
        logo.LoadImage(bytes);
    }

    float lastFilmTime = 0.0f;


	// Update is called once per frame
	void Update () {

        timeBlockList.Clear();
        //make a list of timeblocks in timeline
        
        foreach(Transform t in timeline.transform)
        {
            if(t.gameObject.GetComponent<timeBlock>() != null)
            {
                timeBlockList.Add(t.gameObject);
            }
        }


        float maxRelPosition = 0.0f;
        float maxHeight = 0.0f;
        int maxIdx = 0;
        GameObject maxTb = null;
        //Debug.Log("timeblock list size: " + timeBlockList.Count);
        for (int i = 0; i < timeBlockList.Count; i++)
        {
            GameObject tb = timeBlockList[i];
            bool valid = false;
            float dist = Mathf.Abs(gameObject.transform.localPosition.x - tb.transform.localPosition.x);
            valid = dist < tb.transform.localScale.x / 2.0f;
            //Debug.Log("valid: " + valid + " dist: " + dist);
            if (valid)
            {
                
                if(tb.transform.localPosition.z < maxHeight)
                {
                    maxHeight = tb.transform.localPosition.z;
                    maxRelPosition = -gameObject.transform.localPosition.x + tb.transform.localPosition.x;
                    maxRelPosition = maxRelPosition / tb.transform.localScale.x;
                    maxIdx = i;
                    maxTb = tb;
                }
            }
        }


        if (maxTb != null)
        {

            //do it fast only in seek mode

            //if in play film mode, do it 1/30 seconds;


            //request texture frame at position
            GameObject mclip = maxTb.GetComponent<timeBlock>().associatedMclip;

            //if (filmPlayButton.GetComponent<filmPlayButton>().playModeActive)
            if (true)
            {
                if ((Time.time - lastFilmTime) > (1 / 30.0f))
                {
                    lastFilmTime = Time.time;
                    mclip.GetComponent<magicClip>().applyImage(maxRelPosition, preview);
                }

            }
            else
            {
                mclip.GetComponent<magicClip>().applyImage(maxRelPosition, preview);
            }

            

        }else
        {

            //load logo
            preview.GetComponent<MeshRenderer>().material.mainTexture = logo;



        }





	}


    void OnTriggerStay(Collider other)
    {
        if(other.gameObject.GetComponent<timeBlock>() != null)
        {





        }
    }

}
