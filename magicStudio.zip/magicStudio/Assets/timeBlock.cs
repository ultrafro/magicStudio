﻿using UnityEngine;
using System.Collections;

public class timeBlock : MonoBehaviour {

    public GameObject associatedMclip;

	// Use this for initialization
	void Start () {


        
    }

    // Update is called once per frame
    void Update()
    {
    }

    float factor = 1.2f / (300.0f * 30.0f);
    public void loadClip(GameObject mclip, GameObject blockModel)
    {
        associatedMclip = mclip;

        //figure out length
        int size = mclip.GetComponent<magicClip>().endClipFrame - mclip.GetComponent<magicClip>().startClipFrame;

        //find prototype:

        gameObject.transform.rotation = blockModel.transform.rotation;
        gameObject.transform.localScale = new Vector3((float)size * factor, blockModel.transform.localScale.y, blockModel.transform.localScale.z);

        //figure out location based on mClip location;
        gameObject.transform.position = mclip.transform.position;




    }
}
