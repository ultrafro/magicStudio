﻿using UnityEngine;
using System.Collections;

public class draggable : MonoBehaviour
{


    public GameObject previousParent = null;
    public bool highlightBox = false;

    // Use this for initialization
    void Start()
    {
        if (gameObject.transform.parent != null)
        {
            previousParent = gameObject.transform.parent.gameObject;
        }


        setupRigidbody();
        setupCollider();

    }

    void setupRigidbody()
    {
        //check for collider and add it if it does not exist:
        if (gameObject.GetComponent<Rigidbody>() == null)
        {
            gameObject.AddComponent<Rigidbody>();
        }
        gameObject.GetComponent<Rigidbody>().isKinematic = true;

    }

    void setupCollider()
    {
        //I think i got them all...
        BoxCollider boxC = gameObject.GetComponent<BoxCollider>();
        if (boxC)
        {
            boxC.isTrigger = true;
        }

        CapsuleCollider capsuleC = gameObject.GetComponent<CapsuleCollider>();
        if (capsuleC)
        {
            capsuleC.isTrigger = true;
        }

        SphereCollider sphereC = gameObject.GetComponent<SphereCollider>();
        if (sphereC)
        {
            sphereC.isTrigger = true;
        }

        MeshCollider meshC = gameObject.GetComponent<MeshCollider>();
        if (meshC)
        {
            meshC.isTrigger = true;
        }

        WheelCollider wheelC = gameObject.GetComponent<WheelCollider>();
        if (wheelC)
        {
            wheelC.isTrigger = true;
        }

        TerrainCollider terrainC = gameObject.GetComponent<TerrainCollider>();
        if (terrainC)
        {
            terrainC.isTrigger = true;
        }

        if (boxC == null && capsuleC == null && sphereC == null && meshC == null && wheelC == null && terrainC == null)
        {
            BoxCollider bc = gameObject.AddComponent<BoxCollider>();
            bc.size = new Vector3(0.1f, 0.1f, 0.1f);
            bc.isTrigger = true;
        }


    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnTriggerStay(Collider other)
    {

        //Debug.Log(other.gameObject);



        if (other.gameObject.name != "basket")
        {
            return;
        }
        GameObject basket = other.gameObject;

        //Debug.Log("Other: " + other);







        //GameObject basket = other.gameObject.transform.Find("basket").gameObject;
        GameObject controller = other.transform.parent.gameObject;

        if (basket != null)
        {
            int controllerIdx = (int)other.transform.parent.gameObject.GetComponent<SteamVR_TrackedObject>().index;
            bool clicked = SteamVR_Controller.Input(controllerIdx).GetPress(SteamVR_Controller.ButtonMask.Trigger);
            int childCount = 0;
            foreach (Transform t in basket.transform)
            {
                childCount++;
            }
            bool basketEmpty = childCount == 0;
            //Debug.Log("Basket: " + basketEmpty + " press: " + clicked);


            if (basketEmpty && clicked)
            {
                transform.parent = basket.transform;
            }

            if (!basketEmpty && clicked)
            {

            }

            if (!basketEmpty && !clicked)
            {

                if (previousParent != null)
                {
                    transform.parent = previousParent.transform;
                }
                else
                {
                    transform.parent = null;
                }

            }

            if (basketEmpty && !clicked)
            {
                SteamVR_Controller.Input(controllerIdx).TriggerHapticPulse();
            }


        }
    }
}
