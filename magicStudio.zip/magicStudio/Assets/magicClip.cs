﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class magicClip : MonoBehaviour {

    public GameObject magicClipPrefab;

    public int originalEndClipFrame = 0;
    public int originalStartClipFrame = 0;
    public int startClipFrame = 0;
    public int endClipFrame = 0;
    public string dir = "C:\\Users\\hisham\\Desktop\\processed_file_2016-10-08-19-05-48";

    List<string> imgFileList;
    List<Texture2D> twitchFileTextureList;

    public GameObject topCard;
    public GameObject bottomCard;
    public GameObject leftKnob;
    public GameObject rightKnob;
    public GameObject leftMaxPosition;
    public GameObject rightMaxPosition;

    private Vector3 leftKnobOriginalPosition;
    private Vector3 rightKnobOriginalPosition;

    public GameObject previewCard;
    public GameObject twitchCard;

    public float slowPlayFPS = 30.0f;
    public float twitchPlayFPS = 30.0f;
    private bool slowPlayOn = false;
    private bool twitchPlayOn = false;
    public int twitchSize = 4;
    

    public GameObject deepCopy()
    {

        Debug.Log("deep copy!");
        /*
        GameObject newClip = Instantiate(magicClipPrefab);
        
        
        newClip.GetComponent<magicClip>().originalEndClipFrame = originalEndClipFrame;
        newClip.GetComponent<magicClip>().startClipFrame = startClipFrame;
        newClip.GetComponent<magicClip>().endClipFrame = endClipFrame;
        newClip.GetComponent<magicClip>().dir = dir;

        newClip.GetComponent<magicClip>().leftKnob.transform.position = leftKnob.transform.position;
        newClip.GetComponent<magicClip>().leftKnob.transform.rotation = leftKnob.transform.rotation;

        newClip.GetComponent<magicClip>().rightKnob.transform.position = rightKnob.transform.position;
        newClip.GetComponent<magicClip>().rightKnob.transform.rotation = rightKnob.transform.rotation;

        newClip.GetComponent<magicClip>().leftMaxPosition.transform.position = leftMaxPosition.transform.position;
        newClip.GetComponent<magicClip>().leftMaxPosition.transform.rotation = leftMaxPosition.transform.rotation;

        newClip.GetComponent<magicClip>().rightMaxPosition.transform.position = rightMaxPosition.transform.position;
        newClip.GetComponent<magicClip>().rightMaxPosition.transform.rotation = rightMaxPosition.transform.rotation;

        newClip.GetComponent<magicClip>().slowPlayFPS = slowPlayFPS;
        newClip.GetComponent<magicClip>().twitchPlayFPS = twitchPlayFPS;
        newClip.GetComponent<magicClip>().twitchSize = twitchSize;

        
        newClip.GetComponent<magicClip>().restart();
        

        return newClip;
        */
        
        return new GameObject();


    }


    public void applyImage(float relativePosition, GameObject obj)
    {
        int size = endClipFrame - startClipFrame;
        int middle = (int) Mathf.Floor(startClipFrame + size / 2);

        int requestedFrame = (int)((float)middle + relativePosition * size);

        //load bytes from file system
        Texture2D tex = new Texture2D(2, 2); //create a new video texture in gpu
        byte[] bytes = File.ReadAllBytes(imgFileList[requestedFrame]); //load bytes from image file to cpu
        tex.LoadImage(bytes); //transfer them to the gpu texture
        obj.GetComponent<Renderer>().material.mainTexture = tex; //apply this gpu texture to a 3d object

        //apply texture to obj


    }


    // Use this for initialization
    void Start () {
        imgFileList = new List<string>();
        twitchFileTextureList = new List<Texture2D>();
        loadDirectory(dir);
        loadTwitch();

        setStartClipFrame(startClipFrame);
        setEndClipFrame(endClipFrame);

        leftKnobOriginalPosition = leftKnob.transform.localPosition;
        rightKnobOriginalPosition = rightKnob.transform.localPosition;

        slowPlayOn = false;
        twitchPlayOn = true;

    }

    public void restart()
    {

        imgFileList.Clear();
        twitchFileTextureList.Clear();


        imgFileList = new List<string>();
        twitchFileTextureList = new List<Texture2D>();
        loadDirectory(dir);
        loadTwitch();

        setStartClipFrame(startClipFrame);
        setEndClipFrame(endClipFrame);

        leftKnobOriginalPosition = leftKnob.transform.localPosition;
        rightKnobOriginalPosition = rightKnob.transform.localPosition;

        slowPlayOn = false;
        twitchPlayOn = true;
    }

    void loadTwitch()
    {
        //assume file list is loaded....

        for(int i = 0; i<twitchSize; i++)
        {
            int clipFrame = (int) Mathf.Floor( ((float)i / (float)twitchSize) * (imgFileList.Count-1));
            //Debug.Log("Adding clip frame to twitch list: " + clipFrame);

            byte[] bytes = File.ReadAllBytes(imgFileList[clipFrame]); //load bytes from image file to cpu

            Texture2D tex = new Texture2D(2, 2); //create a new video texture in gpu
            tex.LoadImage(bytes);
            twitchFileTextureList.Add(tex);

        }
        
    }

    void loadDirectory(string path)
    {
        imgFileList.Clear();

        var info = new DirectoryInfo(path);
        var fileInfo = info.GetFiles();

        for (int i = 0; i < fileInfo.Length; i++)
        {
            FileInfo file = fileInfo[i];
            bool valid = (file.Name.Contains(".png") || file.Name.Contains(".jpg"));
            if (valid)
            {
                string fullFile = path + "/" + file.Name;
                imgFileList.Add(fullFile);
                //Debug.Log("loading file: " + fullFile);


                /*don't load it, it takes too much memory
                 
                byte[] bytes = File.ReadAllBytes(fullFile); //load bytes from image file to cpu

                Texture2D tex = new Texture2D(2, 2); //create a new video texture in gpu
                tex.LoadImage(bytes);
                imgFileTexture.Add(tex);
                */





            }
        }
    }
	
	// Update is called once per frame
	void Update () {


        updateCards();
        if (slowPlayOn)
        {
            previewCard.SetActive(true);
            slowPlay(slowPlayFPS);
        }else
        {
            previewCard.SetActive(false);
        }


        if (twitchPlayOn)
        {
            twitchCard.SetActive(true);
            twitchPlay(twitchPlayFPS);
        }else
        {
            twitchCard.SetActive(false);
        }
        

    }

    void updateCards()
    {
        //if position of knobs has changed

        int newStartClipFrame = startKnobToClipFrame();
        //Debug.Log("new start: " + newStartClipFrame + " old start: " + startClipFrame);
        if (newStartClipFrame != startClipFrame)
        {
            //Debug.Log("updating left with: " + newStartClipFrame);
            Debug.Log("loading start clip: " + newStartClipFrame);
            setStartClipFrame(newStartClipFrame);
        }

        int newEndClipFrame = endKnobToClipFrame();
        //Debug.Log("new end: " + newEndClipFrame + " old end: " + endClipFrame);
        if (newEndClipFrame != endClipFrame)
        {
            //Debug.Log("updating right with: " + newEndClipFrame);
            Debug.Log("loading start clip: " + newEndClipFrame);
            setEndClipFrame(newEndClipFrame);
        }

    }

    int startKnobToClipFrame()
    {

        int newFrameOffset = 0;

        //float xOffset = leftKnob.transform.localPosition.x - leftKnobOriginalPosition.x;

        GameObject dummy = new GameObject();
        dummy.transform.position = leftKnob.transform.position;
        dummy.transform.parent = gameObject.transform;


        float xOffset = dummy.transform.localPosition.x;

        GameObject.Destroy(dummy);


        //Debug.Log("left offset: " + xOffset);
        float maxOffset = 1.0f*Mathf.Abs(leftMaxPosition.transform.localPosition.x);
        //Debug.Log("max offset: " + maxOffset);

        
        float proportion = Mathf.Clamp(xOffset / maxOffset,-1.0f,1.0f);

        int n = imgFileList.Count - 1;

        int newFrameNumber = (int)(n / 2.0f -+ proportion * (n / 2.0f));

        //Debug.Log("proportion: " + proportion);

        //int newFrameNumber =(int) Mathf.Floor((-(imgFileList.Count - 0.0f) / 2.0f * proportion + (imgFileList.Count - 0.0f) / 2.0f));

        //int newFrameNumber = (int) Mathf.Floor(originalStartClipFrame + ((0 - startClipFrame) * proportion));
        //Debug.Log("new start frame number: " + newFrameNumber);
        return newFrameNumber;

    }


    int endKnobToClipFrame()
    {

        int newFrameOffset = 0;

        GameObject dummy = new GameObject();
        dummy.transform.position = rightKnob.transform.position;
        dummy.transform.parent = gameObject.transform;
        

        //float xOffset = leftKnob.transform.localPosition.x - leftKnobOriginalPosition.x;
        float xOffset = dummy.transform.localPosition.x;

        GameObject.Destroy(dummy);

        //Debug.Log("left offset: " + xOffset);
        float maxOffset = 1.0f * Mathf.Abs(rightMaxPosition.transform.localPosition.x);
        //Debug.Log("max offset: " + maxOffset);


        float proportion = Mathf.Clamp(xOffset / maxOffset, -1.0f, 1.0f);

        int n = imgFileList.Count - 1;

        int newFrameNumber = (int)(n / 2.0f - proportion * (n / 2.0f));
        return newFrameNumber;
        
    }


    public void loadStack(string path)
    {

    }


    public bool togglePlay()
    {
        slowPlayOn = !slowPlayOn;
        if (!slowPlayOn)
        {
            Debug.Log("turnign twitch play back on");
            twitchPlay(twitchPlayFPS);
        }
        return slowPlayOn;
    }

    float lastClipFrameTime;
    int playCount = 0;
    public void slowPlay(float fps)
    {
        twitchPlayOn = false;
        //previewCard.SetActive(true);
        //Debug.Log("inside slow play");
        float now = Time.time;
        if ((now - lastClipFrameTime) > (1 / fps))
        {
            playCount++;
            lastClipFrameTime = now;



            int clipFrame = startClipFrame +  (playCount % (Mathf.Max(endClipFrame - startClipFrame,0))); //determine clip frame
            //Debug.Log("loading preview card: " + clipFrame);
            loadPreviewCard(clipFrame);
        }
        else
        {
            //Debug.Log("not yet, fps: " + fps + " elapsed time: " + (now - lastClipFrameTime));
        }
    }


    float lastTwitchFrameTime = 0.0f;
    int twitchPlayCount = 0;
    public void twitchPlay(float twitchPlayFPS)
    {
        slowPlayOn = false;
        twitchPlayOn = true;
        //previewCard.SetActive(true);
        //Debug.Log("inside slow play");
        //twitchCard.SetActive(true);
        float now = Time.time;
        if ((now - lastTwitchFrameTime) > (1 / twitchPlayFPS))
        {
            twitchPlayCount++;
            lastTwitchFrameTime = now;



            int twitchFrame = twitchPlayCount % twitchFileTextureList.Count;

            
            //Debug.Log("loading preview card: " + clipFrame);
            loadTwitchCard(twitchFrame);
        }
        else
        {
            //Debug.Log("not yet, fps: " + fps + " elapsed time: " + (now - lastClipFrameTime));
        }
    }

    void loadTwitchCard(int twitchFrame)
    {
        //Debug.Log("Loading twitch frame: " + twitchFrame);
        twitchCard.GetComponent<Renderer>().material.mainTexture = twitchFileTextureList[twitchFrame]; //apply this gpu texture to a 3d object
    }

    public void setStartClipFrame(int newStartClipFrame)
    {
        startClipFrame = newStartClipFrame;

        //load the new image to the top card
        loadTopCard(startClipFrame);
    }

    public void setEndClipFrame(int newEndClipFrame)
    {
        endClipFrame = newEndClipFrame;

        //load the new image to the bottom card
        loadBottomCard(endClipFrame);
    }


    void loadTopCard(int clipFrameNumber)
    {
        //for when we were loading it slow
        Texture2D tex = new Texture2D(2, 2); //create a new video texture in gpu
        byte[] bytes = File.ReadAllBytes(imgFileList[clipFrameNumber]); //load bytes from image file to cpu
        tex.LoadImage(bytes); //transfer them to the gpu texture
        topCard.GetComponent<Renderer>().material.mainTexture = tex; //apply this gpu texture to a 3d object
    }

    void loadBottomCard(int clipFrameNumber)
    {
        //for when we were loading it slow
        Texture2D tex = new Texture2D(2, 2); //create a new video texture in gpu
        byte[] bytes = File.ReadAllBytes(imgFileList[clipFrameNumber]); //load bytes from image file to cpu
        tex.LoadImage(bytes); //transfer them to the gpu texture
        bottomCard.GetComponent<Renderer>().material.mainTexture = tex; //apply this gpu texture to a 3d object

    }

    void loadPreviewCard(int clipFrameNumber)
    {
        //for when we were loading it slow
        Texture2D tex = new Texture2D(2, 2); //create a new video texture in gpu
        byte[] bytes = File.ReadAllBytes(imgFileList[clipFrameNumber]); //load bytes from image file to cpu
        tex.LoadImage(bytes); //transfer them to the gpu texture
        previewCard.GetComponent<Renderer>().material.mainTexture = tex; //apply this gpu texture to a 3d object

    }




    public void collapse()
    {
        //adjust the position of the knobs/cards to be proportional to be on top of each other
    }

    public void expand()
    {
        //adjust the position of the knobs/cards to be proportional to the clip frame numbers
    }

    public void stop()
    {
        slowPlayOn = false;
        twitchPlayOn = false;
    }

    public void stopSlowPlay()
    {
        slowPlayOn = false;
    }

    public void stopTwitchPlay()
    {
        twitchPlayOn = false;
    }





}
