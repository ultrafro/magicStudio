﻿using UnityEngine;
using System.Collections;

public class playButton : MonoBehaviour {

    public GameObject magicClip;


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnTriggerStay(Collider other)
    {
        if (other.gameObject.name == "basket")
        {
            //Debug.Log("touching basket!");
            int controllerIdx = (int)other.transform.parent.gameObject.GetComponent<SteamVR_TrackedObject>().index;


            bool clicked = SteamVR_Controller.Input(controllerIdx).GetPressDown(SteamVR_Controller.ButtonMask.Trigger);
            int childCount = 0;
            foreach (Transform t in other.gameObject.transform)
            {
                childCount++;
            }
            bool basketEmpty = childCount == 0;
            //Debug.Log("Basket: " + basketEmpty + " press: " + clicked);

            if (basketEmpty && clicked)
            {
                bool isCurrentlyPlaying = magicClip.GetComponent<magicClip>().togglePlay();
                if (isCurrentlyPlaying)
                {
                    gameObject.GetComponent<MeshRenderer>().enabled = false;
                }
                else
                {
                    gameObject.GetComponent<MeshRenderer>().enabled = true;
                }
            }


            SteamVR_Controller.Input(controllerIdx).TriggerHapticPulse();

        }
    }
}
