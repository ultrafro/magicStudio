﻿using UnityEngine;
using System.Collections;

public class storyBoard : MonoBehaviour {

    public int clipCount = 0;
    public int numRows = 3;
    public int numCols = 3;

    public float xOffset = 0.5f;
    public float yOffset = 0.2f;
    float zOffset = .8f;

    public GameObject left;
    public GameObject right;

    public GameObject storyBoardModel;

    public float shiftSpeed = 0.1f;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

        Vector2 areaRight = new Vector2(0.0f, 0.0f);
        Vector2 areaLeft = new Vector2(0.0f, 0.0f);
        bool clickedRight = false;
        bool clickedLeft = false;
        int controllerIdxRight = 0;
        int controllerIdxLeft = 0;

        if(right.activeSelf)
        {
            controllerIdxRight = (int)right.GetComponent<SteamVR_TrackedObject>().index;
            clickedRight = SteamVR_Controller.Input(controllerIdxRight).GetPress(SteamVR_Controller.ButtonMask.Touchpad);
            areaRight = SteamVR_Controller.Input(controllerIdxRight).GetAxis(Valve.VR.EVRButtonId.k_EButton_Axis0);

        }
        
        if(left.activeSelf)
        {
            controllerIdxLeft = (int)left.GetComponent<SteamVR_TrackedObject>().index;
            clickedLeft = SteamVR_Controller.Input(controllerIdxLeft).GetPress(SteamVR_Controller.ButtonMask.Touchpad);
            areaLeft = SteamVR_Controller.Input(controllerIdxRight).GetAxis(Valve.VR.EVRButtonId.k_EButton_Axis0);

        }

        //Debug.Log(" " + clickedRight + " " + clickedLeft + " " + areaRight + " " + areaLeft);

        float thresh = 0.6f;
        if (Mathf.Abs(areaRight.x) > Mathf.Abs(areaRight.y))
        {
            if (areaRight.x > thresh && clickedRight)
            {
                moveRight();
            }

            if (areaRight.x < -thresh && clickedRight)
            {
                moveLeft();
            }
        }

        if (Mathf.Abs(areaLeft.x) > Mathf.Abs(areaLeft.y))
        {
            if (areaLeft.x > thresh && clickedRight)
            {
                moveRight();
            }

            if (areaLeft.x < -thresh && clickedRight)
            {
                moveLeft();
            }
        }


    }

    void moveLeft()
    {
        GameObject dummy = new GameObject();
        dummy.transform.parent = gameObject.transform;
        dummy.transform.localPosition = new Vector3(0.0f, 0.0f, 0.0f);


        //Debug.Log("new position: " + dummy.transform.localPosition + " shift speed " + shiftSpeed);
        Vector3 newPosition = new Vector3();

        newPosition.x = dummy.transform.localPosition.x - shiftSpeed;
        newPosition.y = dummy.transform.localPosition.y;
        newPosition.z = dummy.transform.localPosition.z;
        
        //Debug.Log("new position: " + newPosition + " shift speed " + shiftSpeed);
        dummy.transform.localPosition = newPosition;
        dummy.transform.parent = null;
        newPosition = dummy.transform.position;
        gameObject.transform.position = newPosition;
        GameObject.Destroy(dummy);
    }

    void moveRight()
    {
        GameObject dummy = new GameObject();
        dummy.transform.parent = gameObject.transform;
        dummy.transform.localPosition = new Vector3(0.0f, 0.0f, 0.0f);


        //Debug.Log("new position: " + dummy.transform.localPosition + " shift speed " + shiftSpeed);
        Vector3 newPosition = new Vector3();

        newPosition.x = dummy.transform.localPosition.x + shiftSpeed;
        newPosition.y = dummy.transform.localPosition.y;
        newPosition.z = dummy.transform.localPosition.z;

        //Debug.Log("new position: " + newPosition + " shift speed " + shiftSpeed);
        dummy.transform.localPosition = newPosition;
        dummy.transform.parent = null;
        newPosition = dummy.transform.position;
        gameObject.transform.position = newPosition;
        GameObject.Destroy(dummy);
    }

    public void addClip(GameObject newMclip)
    {



        GameObject mclip = newMclip;
        //mclip.GetComponent<draggable>().previousParent = gameObject;
        mclip.transform.parent = gameObject.transform;

        GameObject dummy = new GameObject();
        dummy.transform.parent = storyBoardModel.transform;
        dummy.transform.rotation = storyBoardModel.transform.rotation;
        Vector3 newPosition = dummy.transform.localPosition;
        //newPosition.x = ((clipCount % numRows) - ((float)numRows/2.0f)) * xOffset;
        newPosition.x = ((clipCount % numCols) - Mathf.Floor(numCols / 2)) * xOffset;
        newPosition.y = ((clipCount / numCols) - Mathf.Floor(numRows / 2)) * yOffset;

        newPosition.x = clipCount * xOffset;
        newPosition.y = 0.0f;


        //newPosition.y = (((int)clipCount / numCols) - ((float)numCols/2.0f) )*yOffset;
        newPosition.z = zOffset;

        //Debug.Log("Clip COunt: " + clipCount + " x pos: " + newPosition.x + " ypos " + newPosition.y);

        dummy.transform.localPosition = newPosition;

        mclip.transform.position = dummy.transform.position;
        mclip.transform.rotation = dummy.transform.rotation;

        GameObject.Destroy(dummy);
        clipCount++;
    }
}

