﻿using UnityEngine;
using System.Collections;

public class filmPlayButton : MonoBehaviour
{

    //public GameObject magicClip;
    public bool playModeActive = false;
    public float clickedSize = 1.5f;
    public float hoverSize = 1.2f;
    public float playStartTime = 0.0f;
    float originalSize;

    // Use this for initialization
    void Start()
    {
        originalSize = gameObject.transform.localScale.x;

    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnTriggerStay(Collider other)
    {
        if (other.gameObject.name == "basket")
        {
            //Debug.Log("touching basket!");
            int controllerIdx = (int)other.transform.parent.gameObject.GetComponent<SteamVR_TrackedObject>().index;


            bool clicked = SteamVR_Controller.Input(controllerIdx).GetPressDown(SteamVR_Controller.ButtonMask.Trigger);
            int childCount = 0;
            foreach (Transform t in other.gameObject.transform)
            {
                childCount++;
            }
            bool basketEmpty = childCount == 0;
            //Debug.Log("Basket: " + basketEmpty + " press: " + clicked);

            if (basketEmpty && clicked)
            {
                playModeActive = !playModeActive;
                if (playModeActive)
                {
                    playStartTime = Time.time;
                }
                
            }

            if (playModeActive)
            {
                gameObject.transform.localScale = new Vector3(clickedSize*originalSize, clickedSize* originalSize, 0.01f);
            }else
            {
                gameObject.transform.localScale = new Vector3(hoverSize* originalSize, hoverSize* originalSize, 0.01f);
            }
            

            SteamVR_Controller.Input(controllerIdx).TriggerHapticPulse();

        }
    }
}
