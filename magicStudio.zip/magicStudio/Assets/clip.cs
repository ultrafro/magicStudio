﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class clip : MonoBehaviour {

    public string dir = "C:\\Users\\hisham\\Desktop\\processed_file_2016-10-08-19-05-48";
    List<string> imgFiles;
    public GameObject topCard;
    List<Texture2D> imgFileTexture;



    // Use this for initialization
    void Start () {
        imgFiles = new List<string>();
        imgFileTexture = new List<Texture2D>();
        loadDirectory(dir);

	}


    void loadDirectory(string path)
    {
        imgFiles.Clear();

        var info = new DirectoryInfo(path);
        var fileInfo = info.GetFiles();
        
        for(int i = 0; i<fileInfo.Length; i++)
        {
            FileInfo file = fileInfo[i];
            bool valid = (file.Name.Contains(".png") || file.Name.Contains(".jpg"));
            if (valid)
            {
                string fullFile = path + "/" + file.Name;
                imgFiles.Add(fullFile);
                //Debug.Log("loading file: " + fullFile);
                
                byte[] bytes = File.ReadAllBytes(fullFile); //load bytes from image file to cpu

                Texture2D tex = new Texture2D(2, 2); //create a new video texture in gpu
                tex.LoadImage(bytes);
                imgFileTexture.Add(tex);





            }
        }
    }


    int count = 0;
    public float fps;
    float lastClipFrameTime;

	// Update is called once per frame
	void Update () {
        //Debug.Log("fps: " + fps);
        float now = Time.time;
        if((now - lastClipFrameTime) > (1 / fps))
        {
            count++;
            lastClipFrameTime = now;
        }else
        {
            Debug.Log("not yet, fps: " + fps + " elapsed time: " + (now - lastClipFrameTime));
        }


        int clipFrame = count % imgFiles.Count; //determine clip frame

        /* for when we were loading it slow
        Texture2D tex = new Texture2D(2, 2); //create a new video texture in gpu
        byte[] bytes = File.ReadAllBytes(imgFiles[clipFrame]); //load bytes from image file to cpu
        tex.LoadImage(bytes); //transfer them to the gpu texture
        */



        topCard.GetComponent<Renderer>().material.mainTexture = imgFileTexture[clipFrame]; //apply this gpu texture to a 3d object
        //count++;


    }
}
